﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace coding_challenge
{
    internal class DBUtil
    {
        private readonly string connectionString;

        // Constructor
        public DBUtil(string serverName, string databaseName)
        {
            connectionString = $"Server = DESKTOP-S44ARGN\\SQLEXPRESS; DataBase=LoanManagementSystem;Trusted_Connection = True;TrustServerCertificate=True;";
        }

        // Method to execute SQL query and return a DataTable
        public DataTable ExecuteQuery(string query)
        {
            DataTable dataTable = new DataTable();

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        adapter.Fill(dataTable);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while executing the query: {ex.Message}");
            }

            return dataTable;
        }

    }
}
