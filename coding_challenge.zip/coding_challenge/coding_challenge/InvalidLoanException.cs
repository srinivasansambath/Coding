﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace coding_challenge
{
    internal class InvalidLoanException : Exception
    {
        public InvalidLoanException(string message)
        : base(message)
        {
        }
        public InvalidLoanException(string message, Exception innerException)
        : base(message, innerException)
        {
        }
    }
}
