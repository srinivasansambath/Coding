﻿using coding_challenge;
using System;

class LoanManagement
{
    static void Main(string[] args)
    {
        // Database connection details
        string serverName = "DESKTOP-S44ARGN\\SQLEXPRESS";
        string databaseName = "LoanManagementSystem";

        // Create an instance of LoanRepository
        ILoanRepository loanRepository = new LoanRepository(serverName, databaseName);

        bool exit = false;

        // Main loop for the loan management system
        while (!exit)
        {
            // Display menu
            Console.WriteLine("\nLoan Management System");
            Console.WriteLine("1. Apply for a Loan");
            Console.WriteLine("2. View All Loans");
            Console.WriteLine("3. View Loan Details");
            Console.WriteLine("4. Make Loan Repayment");
            Console.WriteLine("5. Exit");
            Console.Write("Enter your choice: ");

            // Get user choice
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    // Apply for a loan
                    loanRepository.ApplyLoan();
                    break;
                case "2":
                    // View all loans
                    loanRepository.GetAllLoans();
                    break;
                case "3":
                    // View loan details
                    ViewLoanDetails(loanRepository);
                    break;
                case "4":
                    // Make loan repayment
                    MakeLoanRepayment(loanRepository);
                    break;
                case "5":
                    // Exit the program
                    exit = true;
                    Console.WriteLine("Exiting the program...");
                    break;
                default:
                    // Invalid choice
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }
        }
    }


    // Method to view loan details by ID
    static void ViewLoanDetails(ILoanRepository loanRepository)
    {
        Console.Write("Enter Loan ID: ");
        int loanId = int.Parse(Console.ReadLine());
        loanRepository.GetLoanById(loanId);
    }

    // Method to make loan repayment
    static void MakeLoanRepayment(ILoanRepository loanRepository)
    {
        Console.Write("Enter Loan ID: ");
        int loanId = int.Parse(Console.ReadLine());
        Console.Write("Enter Amount: ");
        decimal amount = decimal.Parse(Console.ReadLine());
        int noOfEmisPaid = loanRepository.LoanRepayment(loanId, amount);
        Console.WriteLine($"Paid {noOfEmisPaid} EMIs with the amount of {amount}.");
    }
}
