﻿using coding_challenge.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace coding_challenge
{
    internal class LoanRepository : ILoanRepository
    {
        private readonly DBUtil dbUtil;

        // Constructor
        public LoanRepository(string serverName, string databaseName)
        {
            dbUtil = new DBUtil(serverName, databaseName);
        }

        public void ApplyLoan()
        {
            Console.WriteLine("Do you want to apply for this loan? (Yes/No)");
            string response = Console.ReadLine();

            if (response.Trim().Equals("Yes", StringComparison.OrdinalIgnoreCase))
            {
                string loanStatus = "Pending";

                Console.WriteLine("Enter loan details:");

                Console.Write("Loan ID: ");
                int loanId = int.Parse(Console.ReadLine());

                Console.Write("Customer ID: ");
                int customerId = int.Parse(Console.ReadLine());

                Console.Write("Principal Amount: ");
                decimal principalAmount = decimal.Parse(Console.ReadLine());

                Console.Write("Interest Rate: ");
                decimal interestRate = decimal.Parse(Console.ReadLine());

                Console.Write("Loan Term: ");
                int loanTerm = int.Parse(Console.ReadLine());

                Console.Write("Loan Type (CarLoan/HomeLoan): ");
                string loanType = Console.ReadLine();

                string propertyAddress = null;
                int propertyValue = 0;
                string carModel = null;
                int carValue = 0;

                if (loanType.Equals("HomeLoan", StringComparison.OrdinalIgnoreCase))
                {
                    Console.Write("Property Address: ");
                    propertyAddress = Console.ReadLine();

                    Console.Write("Property Value: ");
                    propertyValue = int.Parse(Console.ReadLine());
                }
                else if (loanType.Equals("CarLoan", StringComparison.OrdinalIgnoreCase))
                {
                    Console.Write("Car Model: ");
                    carModel = Console.ReadLine();

                    Console.Write("Car Value: ");
                    carValue = int.Parse(Console.ReadLine());
                }
                string query = $"INSERT INTO Loan (LoanID, CustomerID, PrincipalAmount, InterestRate, LoanTerm, LoanType, LoanStatus, PropertyAddress, PropertyValue, CarModel, CarValue) " +
                           $"VALUES ({loanId}, {customerId}, {principalAmount}, {interestRate}, {loanTerm}, '{loanType}', '{loanStatus}', '{propertyAddress}', {propertyValue}, '{carModel}', {carValue})";
                dbUtil.ExecuteQuery(query);
                Console.WriteLine("Loan application submitted successfully.");
            }
            else
            {
                Console.WriteLine("Loan application cancelled.");
            }
        }

        public void CalculateInterest(int loanId)
        {
            // Retrieve loan details from the database
            string query = $"SELECT PrincipalAmount, InterestRate, LoanTerm FROM Loan WHERE LoanID = {loanId}";
            DataTable loanData = dbUtil.ExecuteQuery(query);

            if (loanData.Rows.Count == 0)
            {
                throw new InvalidLoanException($"Loan with ID {loanId} not found.");
            }

            // Extract loan details
            decimal principalAmount = Convert.ToDecimal(loanData.Rows[0]["PrincipalAmount"]);
            decimal interestRate = Convert.ToDecimal(loanData.Rows[0]["InterestRate"]);
            int loanTerm = Convert.ToInt32(loanData.Rows[0]["LoanTerm"]);

            // Calculate interest amount
            Console.WriteLine("Intereset Amount is : {0}", (principalAmount * interestRate * loanTerm) / 12);
        }

        public void CalculateInterest(int loanId, decimal principalAmount, decimal interestRate, int loanTerm)
        {
            // Calculate interest amount
            Console.WriteLine("The Intereset is : {0}", (principalAmount * interestRate * loanTerm) / 12);
        }
        public void LoanStatus(int loanId)
        {
            try
            {
                // Retrieve loan details from the database
                string query = $"SELECT CreditScore FROM Loan WHERE LoanID = {loanId}";
                DataTable loanData = dbUtil.ExecuteQuery(query);

                if (loanData.Rows.Count == 0)
                {
                    throw new InvalidLoanException($"Loan with ID {loanId} not found.");
                }

                // Extract credit score
                int creditScore = Convert.ToInt32(loanData.Rows[0]["CreditScore"]);

                // Determine loan status based on credit score
                string loanStatus = creditScore > 650 ? "Approved" : "Rejected";

                // Update loan status in the database
                query = $"UPDATE Loan SET LoanStatus = '{loanStatus}' WHERE LoanID = {loanId}";
                dbUtil.ExecuteQuery(query);

                // Display loan status message
                Console.WriteLine($"Loan with ID {loanId} is {loanStatus}.");
            }
            catch (InvalidLoanException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public decimal CalculateEMI(int loanId)
        {
            // Retrieve loan details from the database
            string query = $"SELECT PrincipalAmount, InterestRate, LoanTerm FROM Loan WHERE LoanID = {loanId}";
            DataTable loanData = dbUtil.ExecuteQuery(query);

            if (loanData.Rows.Count == 0)
            {
                throw new InvalidLoanException($"Loan with ID {loanId} not found.");
            }

            // Extract loan details
            decimal principalAmount = Convert.ToDecimal(loanData.Rows[0]["PrincipalAmount"]);
            decimal interestRate = Convert.ToDecimal(loanData.Rows[0]["InterestRate"]);
            int loanTerm = Convert.ToInt32(loanData.Rows[0]["LoanTerm"]);

            // Calculate EMI amount
            return CalculateEMI(principalAmount, interestRate, loanTerm);
        }

        public decimal CalculateEMI(int loanId, decimal principalAmount, decimal interestRate, int loanTerm)
        {
            // Calculate EMI amount
            return CalculateEMI(principalAmount, interestRate, loanTerm);
        }

        // Helper method to calculate EMI amount
        private decimal CalculateEMI(decimal principalAmount, decimal interestRate, int loanTerm)
        {
            // Convert annual interest rate to monthly interest rate
            decimal monthlyInterestRate = interestRate / 12 / 100;

            // Calculate EMI using the formula
            decimal emi = (principalAmount * monthlyInterestRate * (decimal)Math.Pow(1 + (double)monthlyInterestRate, loanTerm)) /
                          ((decimal)Math.Pow(1 + (double)monthlyInterestRate, loanTerm) - 1);


            return emi;
        }
        public int LoanRepayment(int loanId, decimal amount)
        {
            // Retrieve loan details from the database
            string query = $"SELECT PrincipalAmount, InterestRate, LoanTerm FROM Loan WHERE LoanID = {loanId}";
            DataTable loanData = dbUtil.ExecuteQuery(query);

            if (loanData.Rows.Count == 0)
            {
                throw new InvalidLoanException($"Loan with ID {loanId} not found.");
            }

            // Extract loan details
            decimal principalAmount = Convert.ToDecimal(loanData.Rows[0]["PrincipalAmount"]);
            decimal interestRate = Convert.ToDecimal(loanData.Rows[0]["InterestRate"]);
            int loanTerm = Convert.ToInt32(loanData.Rows[0]["LoanTerm"]);

            // Calculate EMI amount
            decimal emi = CalculateEMIvalue(principalAmount, interestRate, loanTerm);

            // Calculate number of EMIs that can be paid with the given amount
            int noOfEmis = (int)Math.Floor(amount / emi);

            if (noOfEmis == 0)
            {
                // If the amount is less than a single EMI, reject the payment
                Console.WriteLine("Payment rejected. Amount is less than a single EMI.");
            }
            else
            {
                // Update loan repayment information in the database
                query = $"UPDATE Loan SET NoOfEmisPaid = NoOfEmisPaid + {noOfEmis} WHERE LoanID = {loanId}";
                dbUtil.ExecuteQuery(query);
            }

            return noOfEmis;
        }

        // Helper method to calculate EMI amount
        private decimal CalculateEMIvalue(decimal principalAmount, decimal interestRate, int loanTerm)
        {
            // Convert annual interest rate to monthly interest rate
            decimal monthlyInterestRate = interestRate / 12 / 100;

            // Calculate EMI using the formula
            decimal emi = (principalAmount * monthlyInterestRate * (decimal)Math.Pow(1 + (double)monthlyInterestRate, loanTerm)) /
                          ((decimal)Math.Pow(1 + (double)monthlyInterestRate, loanTerm) - 1);

            return emi;
        }
        public void GetAllLoans()
        {
            List<Loan> loans = new List<Loan>();
            string query = "SELECT * FROM Loan";
            DataTable loanData = dbUtil.ExecuteQuery(query);
            foreach (DataRow row in loanData.Rows)
            {
                // Extract loan details
                int loanId = Convert.ToInt32(row["LoanID"]);
                int customerId = Convert.ToInt32(row["CustomerID"]);
                decimal principalAmount = Convert.ToDecimal(row["PrincipalAmount"]);
                decimal interestRate = Convert.ToDecimal(row["InterestRate"]);
                int loanTerm = Convert.ToInt32(row["LoanTerm"]);
                string loanType = Convert.ToString(row["LoanType"]);
                string loanStatus = Convert.ToString(row["LoanStatus"]);
            }
            foreach (Loan loan in loans)
            {
                Console.WriteLine($"Loan ID: {loan.LoanID}, Principal Amount: {loan.PrincipalAmount}, Loan Status: {loan.LoanStatus}");
            }

        }
        public void GetLoanById(int loanId)
    {
        try
        {
            // Retrieve loan details from the database
            string query = $"SELECT * FROM Loan WHERE LoanID = {loanId}";
            DataTable loanData = dbUtil.ExecuteQuery(query);

            if (loanData.Rows.Count == 0)
            {
                throw new InvalidLoanException($"Loan with ID {loanId} not found.");
            }

            // Extract loan details
            int customerId = Convert.ToInt32(loanData.Rows[0]["CustomerID"]);
            decimal principalAmount = Convert.ToDecimal(loanData.Rows[0]["PrincipalAmount"]);
            decimal interestRate = Convert.ToDecimal(loanData.Rows[0]["InterestRate"]);
            int loanTerm = Convert.ToInt32(loanData.Rows[0]["LoanTerm"]);
            string loanType = Convert.ToString(loanData.Rows[0]["LoanType"]);
            string loanStatus = Convert.ToString(loanData.Rows[0]["LoanStatus"]);

            // Print loan details
            Console.WriteLine($"Loan ID: {loanId}");
            Console.WriteLine($"Customer ID: {customerId}");
            Console.WriteLine($"Principal Amount: {principalAmount}");
            Console.WriteLine($"Interest Rate: {interestRate}");
            Console.WriteLine($"Loan Term: {loanTerm}");
            Console.WriteLine($"Loan Type: {loanType}");
            Console.WriteLine($"Loan Status: {loanStatus}");
        }
        catch (InvalidLoanException ex)
        {
            Console.WriteLine(ex.Message);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"An error occurred: {ex.Message}");

        }
    }


    }
    }
