﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace coding_challenge.Entities
{
    internal class HomeLoan : Loan
    {
        public string PropertyAddress { get; set; }
        public int PropertyValue { get; set; }

        // Constructor
        public HomeLoan(int loanId, Customer customer, decimal principalAmount, decimal interestRate, int loanTerm, string loanType, string loanStatus, string propertyAddress, int propertyValue)
            : base(loanId, customer, principalAmount, interestRate, loanTerm, loanType, loanStatus)
        {
            PropertyAddress = propertyAddress;
            PropertyValue = propertyValue;
        }
        public HomeLoan()
        {

        }

        public new void PrintInfo()
        {
            base.PrintInfo();
            Console.WriteLine($"Property Address: {PropertyAddress}");
            Console.WriteLine($"Property Value: {PropertyValue}");
        }

    }
}
