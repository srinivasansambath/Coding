﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace coding_challenge
{
    internal interface ILoanRepository
    {
        public void ApplyLoan();
        public void LoanStatus(int loanId);
        public decimal CalculateEMI(int loanId);
        public int LoanRepayment(int loanId, decimal amount);
        public void GetAllLoans();
        public void GetLoanById(int loanId);

    }
}
